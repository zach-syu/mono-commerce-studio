MONO 完整素材包

這些檔案來自已留下 evidence.json 的 E2E 案例與示範素材來源紀錄。

- cases/<案例>/outputs：App 最終成品。
- cases/<案例>/raw-ai 與 model-responses：有保留時，為模型原始回傳圖片。
- cases/<案例>/source：來源商品照片。
- 每個案例的 copy.txt、manifest.json、detail-page.html：完整文案、設定、生成指令与詳情頁。
- samples：開發期間預先產生的 7 張示範圖；來源與模型限制見 sample-provenance.json。
- asset-manifest.json：每個資料檔的大小與 SHA-256，可確認完整性；不代表商品正確性或模型品質已通過人工驗收。

若是分包，請下載 package-index.json 列出的所有分包，解壓到同一個資料夾，再開啟詳情頁。資料路徑保持原本案例關係。
UI 操作截圖留在 HTML 測試報告；每案例 bundle.zip 的內容已解壓納入，本包不重複嵌入 ZIP。
示範組版、開發期 AI 素材與真實模型呼叫必須依各自的 provider/model/證據判讀。
